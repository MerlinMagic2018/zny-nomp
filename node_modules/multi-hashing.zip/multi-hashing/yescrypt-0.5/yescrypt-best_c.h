#ifdef __SSE2__
#include "yescrypt-simd_c.h"
#else
#include "yescrypt-opt_c.h"
#endif
